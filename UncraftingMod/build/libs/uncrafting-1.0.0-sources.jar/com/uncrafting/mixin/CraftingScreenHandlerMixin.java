package com.uncrafting.mixin;

import com.uncrafting.UncraftingHelper;
import net.minecraft.class_1263;
import net.minecraft.class_1714;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1714.class)
public abstract class CraftingScreenHandlerMixin {

    @Inject(method = "onContentChanged", at = @At("HEAD"), cancellable = true)
    private void onContentChanged(class_1263 inventory, CallbackInfo ci) {
        if (UncraftingHelper.IS_UNCRAFTING.get()) {
            ci.cancel();
        }
    }
}
