package com.uncrafting.mixin;

import com.uncrafting.UncraftingHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1714;
import net.minecraft.class_1799;
import net.minecraft.class_3218;

@Mixin(class_1703.class)
public abstract class ScreenHandlerMixin {

    /**
     * BEFORE the click is processed by vanilla.
     * If the player is about to place an item into the result slot (slot 0)
     * of a CraftingScreenHandler, we set IS_UNCRAFTING = true.
     * This prevents CraftingScreenHandler.onContentChanged -> updateResult
     * from immediately clearing slot 0 before our afterSlotClick can run.
     */
    @Inject(method = "onSlotClick", at = @At("HEAD"))
    private void beforeSlotClick(int slotIndex, int button, class_1713 actionType, class_1657 player, CallbackInfo ci) {
        class_1703 handler = (class_1703) (Object) this;
        if (handler instanceof class_1714) {
            if (slotIndex == 0
                    && actionType == class_1713.field_7790
                    && !handler.method_34255().method_7960()
                    && isGridEmpty(handler)) {
                UncraftingHelper.IS_UNCRAFTING.set(true);
            }
        }
    }

    /**
     * AFTER the click is processed by vanilla.
     * At this point, the item should be in slot 0 (because onContentChanged
     * was cancelled by our CraftingScreenHandlerMixin). We now look up
     * the recipe and populate the 3x3 grid.
     */
    @Inject(method = "onSlotClick", at = @At("RETURN"))
    private void afterSlotClick(int slotIndex, int button, class_1713 actionType, class_1657 player, CallbackInfo ci) {
        if (!UncraftingHelper.IS_UNCRAFTING.get()) return;

        class_1703 handler = (class_1703) (Object) this;
        if (handler instanceof class_1714) {
            if (slotIndex == 0) {
                class_1799 outputStack = handler.method_7611(0).method_7677();
                if (!outputStack.method_7960() && player.method_73183() instanceof class_3218 serverWorld) {
                    UncraftingHelper.UncraftResult result = UncraftingHelper.findRecipeFor(outputStack, serverWorld);
                    if (result != null) {
                        class_1799 recipeOutput = result.recipeOutput;

                        if (outputStack.method_7947() >= recipeOutput.method_7947()) {
                            // Handle excess: if they put too many, return the extra
                            if (outputStack.method_7947() > recipeOutput.method_7947()) {
                                class_1799 excess = outputStack.method_7972();
                                excess.method_7939(outputStack.method_7947() - recipeOutput.method_7947());
                                class_1799 kept = outputStack.method_7972();
                                kept.method_7939(recipeOutput.method_7947());
                                handler.method_7611(0).method_53512(kept);
                                if (!player.method_31548().method_7394(excess)) {
                                    player.method_5775(serverWorld, excess);
                                }
                            }

                            // Populate the 3x3 grid with ingredients
                            // IS_UNCRAFTING is still true, so setStack won't trigger updateResult
                            List<class_1799> ingredients = result.ingredients;
                            for (int i = 0; i < 9 && (i + 1) < handler.field_7761.size(); i++) {
                                handler.method_7611(i + 1).method_53512(ingredients.get(i));
                            }
                        }
                    }
                }
            }
        }
        // Always clear the flag at the end
        UncraftingHelper.IS_UNCRAFTING.set(false);
    }

    private boolean isGridEmpty(class_1703 handler) {
        for (int i = 1; i <= 9 && i < handler.field_7761.size(); i++) {
            if (!handler.method_7611(i).method_7677().method_7960()) {
                return false;
            }
        }
        return true;
    }
}
