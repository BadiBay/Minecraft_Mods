package com.uncrafting.mixin;

import net.minecraft.class_1734;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1734.class)
public class CraftingResultSlotMixin {

    @Inject(method = "canInsert", at = @At("HEAD"), cancellable = true)
    private void onCanInsert(class_1799 stack, CallbackInfoReturnable<Boolean> cir) {
        // Allow insertion into the output slot to enable uncrafting
        cir.setReturnValue(true);
    }
}
