package com.uncrafting;

import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1863;
import net.minecraft.class_1867;
import net.minecraft.class_1869;
import net.minecraft.class_3218;
import net.minecraft.class_3955;
import net.minecraft.class_6880;
import net.minecraft.class_8786;
import net.minecraft.recipe.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

public class UncraftingHelper {

    public static final ThreadLocal<Boolean> IS_UNCRAFTING = ThreadLocal.withInitial(() -> false);

    /**
     * Data class holding the result of finding a recipe:
     * the recipe's output stack (for count comparison) and the ingredient stacks.
     */
    public static class UncraftResult {
        public final class_1799 recipeOutput;
        public final List<class_1799> ingredients; // size 9, mapped to 3x3 grid

        public UncraftResult(class_1799 recipeOutput, List<class_1799> ingredients) {
            this.recipeOutput = recipeOutput;
            this.ingredients = ingredients;
        }
    }

    /**
     * Find the first crafting recipe whose output matches the given item
     * and return the ingredients mapped to a 3x3 grid.
     *
     * In 1.21.11, the Recipe API has changed:
     * - RecipeManager is minimal; ServerRecipeManager has values()
     * - Recipe no longer has getResult(). ShapedRecipe/ShapelessRecipe have a package-private `result` field.
     *   We use craft() to get the output.
     * - Ingredient no longer has getMatchingStacks(). Use getMatchingItems() which returns Stream<RegistryEntry<Item>>.
     * - ShapedRecipe.getIngredients() returns List<Optional<Ingredient>>.
     */
    public static UncraftResult findRecipeFor(class_1799 outputStack, class_3218 world) {
        if (outputStack == null || outputStack.method_7960()) {
            return null;
        }

        class_1863 recipeManager = world.method_64577();
        Collection<class_8786<?>> allRecipes = recipeManager.method_8126();

        for (class_8786<?> entry : allRecipes) {
            class_1860<?> recipe = entry.comp_1933();
            if (!(recipe instanceof class_3955 craftingRecipe)) continue;

            // Get the recipe output by checking the result field via cast
            class_1799 recipeOutput;
            List<class_1799> gridStacks = new ArrayList<>();
            for (int i = 0; i < 9; i++) gridStacks.add(class_1799.field_8037);

            if (craftingRecipe instanceof class_1869 shaped) {
                recipeOutput = shaped.field_9053.method_7972();
                if (recipeOutput.method_7909() != outputStack.method_7909()) continue;

                // Map ingredients using width/height
                List<Optional<class_1856>> ingredients = shaped.method_61693();
                int width = shaped.method_8150();
                int height = shaped.method_8158();
                for (int row = 0; row < height; row++) {
                    for (int col = 0; col < width; col++) {
                        int ingredientIndex = row * width + col;
                        int gridIndex = row * 3 + col;
                        if (ingredientIndex < ingredients.size()) {
                            Optional<class_1856> optIngredient = ingredients.get(ingredientIndex);
                            if (optIngredient.isPresent()) {
                                class_1856 ingredient = optIngredient.get();
                                class_1799 stack = ingredientToStack(ingredient);
                                if (!stack.method_7960()) {
                                    gridStacks.set(gridIndex, stack);
                                }
                            }
                        }
                    }
                }
                return new UncraftResult(recipeOutput, gridStacks);

            } else if (craftingRecipe instanceof class_1867 shapeless) {
                recipeOutput = shapeless.field_9050.method_7972();
                if (recipeOutput.method_7909() != outputStack.method_7909()) continue;

                // Shapeless: use IngredientPlacement to get ingredients
                List<class_1856> ingredients = shapeless.method_61671().method_64675();
                for (int i = 0; i < ingredients.size() && i < 9; i++) {
                    class_1856 ingredient = ingredients.get(i);
                    class_1799 stack = ingredientToStack(ingredient);
                    if (!stack.method_7960()) {
                        gridStacks.set(i, stack);
                    }
                }
                return new UncraftResult(recipeOutput, gridStacks);
            }
        }
        return null;
    }

    /**
     * Convert an Ingredient to the first matching ItemStack.
     * In 1.21.11, Ingredient.getMatchingItems() returns Stream<RegistryEntry<Item>>.
     */
    private static class_1799 ingredientToStack(class_1856 ingredient) {
        if (ingredient.method_65799()) return class_1799.field_8037;
        Optional<class_6880<class_1792>> first = ingredient.method_8105().findFirst();
        if (first.isPresent()) {
            return new class_1799(first.get());
        }
        return class_1799.field_8037;
    }
}
