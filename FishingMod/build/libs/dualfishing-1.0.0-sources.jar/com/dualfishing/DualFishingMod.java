package com.dualfishing;

import net.fabricmc.api.ModInitializer;
import net.minecraft.class_1657;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DualFishingMod implements ModInitializer {
    public static final String MOD_ID = "dualfishing";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static final class_2940<Integer> OFF_HAND_FISH_HOOK_ID = class_2945.method_12791(class_1657.class, class_2943.field_13327);

    @Override
    public void onInitialize() {
        LOGGER.info("Initializing Dual Fishing Mod!");
    }
}
