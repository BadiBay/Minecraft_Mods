package com.dualfishing;

import net.minecraft.class_1536;

public interface DualFishingPlayer {
    class_1536 getOffHandFishHook();
    void setOffHandFishHook(class_1536 fishHook);
    boolean isCastingOffhand();
    void setCastingOffhand(boolean castingOffhand);
}
