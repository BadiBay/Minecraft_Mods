package com.dualfishing.mixin;

import com.dualfishing.DualFishingMod;
import com.dualfishing.DualFishingPlayer;
import net.minecraft.class_1536;
import net.minecraft.class_1657;
import net.minecraft.class_2945;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1657.class)
public abstract class PlayerEntityMixin implements DualFishingPlayer {
    @Unique
    private class_1536 offHandFishHook;
    @Unique
    private boolean isCastingOffhand = false;

    @Inject(method = "initDataTracker", at = @At("TAIL"))
    private void onInitDataTracker(class_2945.class_9222 builder, CallbackInfo ci) {
        builder.method_56912(DualFishingMod.OFF_HAND_FISH_HOOK_ID, 0);
    }

    @Override
    public class_1536 getOffHandFishHook() {
        return this.offHandFishHook;
    }

    @Override
    public void setOffHandFishHook(class_1536 fishHook) {
        this.offHandFishHook = fishHook;
        if (!((class_1657)(Object)this).method_73183().method_8608()) {
            ((class_1657)(Object)this).method_5841().method_12778(DualFishingMod.OFF_HAND_FISH_HOOK_ID, fishHook == null ? 0 : fishHook.method_5628());
        }
    }

    @Override
    public boolean isCastingOffhand() {
        return this.isCastingOffhand;
    }

    @Override
    public void setCastingOffhand(boolean castingOffhand) {
        this.isCastingOffhand = castingOffhand;
    }
}
