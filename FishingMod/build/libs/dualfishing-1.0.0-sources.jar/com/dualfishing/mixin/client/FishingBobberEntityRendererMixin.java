package com.dualfishing.mixin.client;

import com.dualfishing.DualFishingPlayer;
import net.minecraft.class_10026;
import net.minecraft.class_1306;
import net.minecraft.class_1536;
import net.minecraft.class_1657;
import net.minecraft.class_906;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_906.class)
public class FishingBobberEntityRendererMixin {

    private static final ThreadLocal<class_1536> CURRENT_BOBBER = new ThreadLocal<>();

    @Inject(method = "updateRenderState(Lnet/minecraft/entity/projectile/FishingBobberEntity;Lnet/minecraft/client/render/entity/state/FishingBobberEntityState;F)V", at = @At("HEAD"))
    private void onUpdateRenderStateHead(class_1536 bobber, class_10026 state, float tickDelta, CallbackInfo ci) {
        CURRENT_BOBBER.set(bobber);
    }

    @Inject(method = "updateRenderState(Lnet/minecraft/entity/projectile/FishingBobberEntity;Lnet/minecraft/client/render/entity/state/FishingBobberEntityState;F)V", at = @At("RETURN"))
    private void onUpdateRenderStateReturn(class_1536 bobber, class_10026 state, float tickDelta, CallbackInfo ci) {
        CURRENT_BOBBER.remove();
    }

    @Redirect(method = "getHandPos", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/entity/FishingBobberEntityRenderer;getArmHoldingRod(Lnet/minecraft/entity/player/PlayerEntity;)Lnet/minecraft/util/Arm;"))
    private class_1306 redirectGetArmHoldingRod(class_1657 player) {
        class_1536 currentBobber = CURRENT_BOBBER.get();
        if (currentBobber != null) {
            int offHandId = player.method_5841().method_12789(com.dualfishing.DualFishingMod.OFF_HAND_FISH_HOOK_ID);
            if (currentBobber.method_5628() == offHandId) {
                return player.method_6068().method_5928();
            }
        }
        return class_906.method_65567(player);
    }
}
