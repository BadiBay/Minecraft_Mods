package com.dualfishing.mixin;

import com.dualfishing.DualFishingPlayer;
import net.minecraft.class_1297;
import net.minecraft.class_1536;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1536.class)
public abstract class FishingBobberEntityMixin {

    @Inject(method = "remove", at = @At("HEAD"))
    private void onRemove(class_1297.class_5529 reason, CallbackInfo ci) {
        class_1536 self = (class_1536)(Object)this;
        class_1657 owner = self.method_6947();
        if (owner != null) {
            if (((DualFishingPlayer) owner).getOffHandFishHook() == self) {
                ((DualFishingPlayer) owner).setOffHandFishHook(null);
            }
        }
    }
}
