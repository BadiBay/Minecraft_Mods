package com.dualfishing.mixin;

import com.dualfishing.DualFishingPlayer;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1536;
import net.minecraft.class_1657;
import net.minecraft.class_1787;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1787.class)
public abstract class FishingRodItemMixin {

    @Inject(method = "use", at = @At("HEAD"), cancellable = true)
    private void onUseHead(class_1937 world, class_1657 user, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
        if (user.method_5715() && hand == class_1268.field_5808) {
            if (user.method_5998(class_1268.field_5810).method_7909() instanceof class_1787) {
                cir.setReturnValue(class_1269.field_5811);
                return;
            }
        }

        if (hand == class_1268.field_5810) {
            class_1536 temp = user.field_7513;
            user.field_7513 = ((DualFishingPlayer) user).getOffHandFishHook();
            ((DualFishingPlayer) user).setOffHandFishHook(temp);
        }
    }

    @Inject(method = "use", at = @At("RETURN"))
    private void onUseReturn(class_1937 world, class_1657 user, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
        if (hand == class_1268.field_5810) {
            class_1536 temp = user.field_7513;
            user.field_7513 = ((DualFishingPlayer) user).getOffHandFishHook();
            ((DualFishingPlayer) user).setOffHandFishHook(temp);
        }
    }
}
